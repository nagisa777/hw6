<?php 
$colors = array("red","green","blue"); 

foreach ($colors as $value) {
  outDiv($value);
}

function outDiv($color)
{
    echo "<div style='width:200px; height:200px;background:$color;'></div>";
}

?>   




